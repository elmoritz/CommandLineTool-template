import Foundation
import ArgumentParser

@main
enum CLI {
    static func main() async {
        await POEditor.main()
    }
}
