import Foundation

protocol ExecutableProgram {
    func run() async throws
}
